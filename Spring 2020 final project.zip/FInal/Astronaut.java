// Import the Random class
import java.util.Random;

// A Class that defines an object of type Astronaut
public class Astronaut {
 

    // fields; there are four of them, and each should be private:
    private String astronautName;
    private double heightMeasurement;
    private int ageMeasurement;

    private double dollarsSpent;
    private double dollarsWon;
    // astronautName of type String
    // heightMeasurement of type double
    // dollarsSpent of type double
    // dollarsWon of type double
    //()
    // method: getHeightMeasurement, public
    public double getHeightMeasurement()  {
    return heightMeasurement;
    }
    
    public int getAgeMeasurement()  {
    return ageMeasurement;

    }
    // input: void
    // output: double
        // description: retrieves the value heightMeasurement field
    //
    // method: setHeightMeasurement, publica   
    public void setHeightMeasurement(double heightMeasure) {
    heightMeasurement = heightMeasure;
    }
     public void setAgeMeasurement(int ageMeasure) {

    ageMeasurement = ageMeasure;
    }
    // input: heightMeasure, which is of type double
    // output: void
    //
    // description: assign the field heightMeasurement to heightMeasure
    // method: gambleAnotherRound, public
    public void gambleAnotherRound(double dollarsBet){
    dollarsSpent += dollarsBet;
    Random randomNumber = new Random();
    
    double randomDouble = randomNumber.nextDouble();
      // input parameter: dollarsBet, which is of type double
    // output: none
    // 
    // description (pseudocode):
    //
    // 1) increment field dollarsSpent by input value dollarsBet
    // 2) declare randomNumbers of be of type Random, and instantiate new random class
    // 3) declare variable randomDouble of type double, and assign it the value output 
    //    by the method nextDouble() of randomNumbers
    
    if (randomDouble < heightMeasurement){ 
                          System.out.println(astronautName + " won");
            dollarsWon += (dollarsBet*1.5);
        } else {
            System.out.println(astronautName + " lost");
            dollarsWon -= dollarsBet;
        }
       }
       public String getAstronautName() {
       return astronautName;
       }
    // method: getAstronautName, public
    // input paramter: none
    // output: value of field astronautName
    
    public double getDollarsSpent() {
    return dollarsSpent;
    }    
    // method: getDollarsSpent, public
    // input paramter: none
    // output: value of field dollarsSpent
    
    
    public double getDollarsWon() {
    return dollarsWon;
    }
    // method: getDollarsWon, public
    // input paramter: none
    // output: value of field dollarsWon;
    
    public double getNetProfit() {
    return dollarsWon - dollarsSpent;
    }
    // method: getNetProfit, public
    // input paramter: none
    // output: result of (dollarsWon - dollarsSpent)
    
    
    
    // Non-default constructor
    // input paramter: name, which is of type String
    // output: NA
    //
    // 1. set astronautName to value in input argument name
    // 2. set dollarsWon to 100 (all Astronauts begin with $100)
    // 3. set dollarsSpent to 0 (all Astronauts begin neutrally)
    public Astronaut(String name) {
                astronautName = name;
        dollarsWon = 100;
        dollarsSpent = 0;
    }
}


