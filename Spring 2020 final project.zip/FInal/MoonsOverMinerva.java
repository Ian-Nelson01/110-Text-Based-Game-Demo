// Ian Nelson
// 6/3/2020
// MoonsOverMinerva.java


// Import Scanner, Io, and Random
import java.util.Scanner; 
import java.io.*;         
import java.util.Random; 

// Define new class
public class MoonsOverMinerva { 


// reads file MinSplash
public static void title()throws IOException{   
File file = new File("MinSplash.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;    
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}
         
// reads file StarsPan
public static void screen()throws IOException{
File file = new File("StarsPan.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}        
                      
// reads file pod                    
public static void pod()throws IOException{ 
File file = new File("pod.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}  

// reads file liftoff
public static void liftoff()throws IOException{ 
File file = new File("liftoff.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}

// reads file Brian
public static void brian()throws IOException{
File file = new File("Brian.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}

// reads file Brian 2
public static void brianTwo()throws IOException{
File file = new File("Brian 2.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}           
   
// reads file Lind
public static void lind()throws IOException{
File file = new File("Lind.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);  
         }}           
      
// reads file Lind 2
public static void lindTwo()throws IOException{
File file = new File("Lind 2.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine); 
         }}           

// reads file Docking     
public static void docking()throws IOException{
File file = new File("Docking.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}           
   
// reads file Docking 2           
public static void dockingTwo()throws IOException{
File file = new File("Docking 2.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}        

// reads file Docking 3   
public static void dockingThree()throws IOException{
File file = new File("Docking 3.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}           
 
// reads file Darwin II ASCII        
public static void darwinIIASCII()throws IOException{
File file = new File("Darwin II ASCII.txt");
Scanner inputFile = new Scanner(file);
   int loopNumber = 0;
   while (inputFile.hasNext()){
      ++loopNumber;
         String fileLine = inputFile.nextLine();
         System.out.println(fileLine);
         }}




      // This method is different, as it contains a story branch.
      
      // reads file liftoff 2
      public static void liftoffTwo()throws IOException{
      {
      String myFileName = "liftoff 2.txt";
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
      ++loopNumber;
      String fileLine = inputFile.nextLine();
      System.out.println(fileLine);
      }
      
      // scanner checks for answer, brian or lind                       
      String choice;
          Scanner scanBoy = new Scanner(System.in);
             choice = scanBoy.nextLine();
              int typoCheck = 0;
      
                 // switch case reads string answers, esecutes methods accordingly
                 switch(choice){          
                    case "Brian": 
                       brian();
                       pressEnter();
                       brianTwo();
                       break;
                    case "Lind": 
                       lind();
                       pressEnter();
                       lindTwo();
                       break;              
                    default:
                    // a little joke i added :)
                       System.out.println("The pod de-oxygenates. In space, typos are deadly.");
                       System.exit(42069);
                    }                          
      }}             
 
// a simple array method that request the player to press enter
// for some reason, having code after the file reading methods makes text scroll smoothly
public static void pressEnter() {
   // lists strings
   String enterRequest[] = {"                                                                    ", "Press", " ", "Enter"};
      // prints chosen strings
      System.out.println(enterRequest[2]);          
      System.out.println(enterRequest[0]  + enterRequest[1] + enterRequest[2] + enterRequest[3] );           
   
   // needs to get a response from scanner before moving on, it can be anything, but enter is suggested.
   String enter;
   Scanner scanBoy = new Scanner(System.in);
      enter = scanBoy.nextLine();
    }

  
// random number generators

// double
public static double ranDoub() {
   Random randomNumber = new Random();
   double randomDouble = randomNumber.nextDouble();
      return randomDouble;
      }
      
// integer
public static int ranInt() {
   Random randomNumber = new Random();
   int randomInteger = randomNumber.nextInt();
      return randomInteger;
      }
                 
                               
                               
                             
    

// main method
public static void main (String[] args) throws IOException
     {
     
     // file reading methods. 
     title();
     pressEnter();
     screen();
     pressEnter();
     pod();
     pressEnter();  
     liftoff();
     pressEnter();
     liftoffTwo();
     pressEnter();
     docking();
      
      
      
      
                      // this block allows player to enter first, last name and a password
                      // it is in the main method, as the name strings can't be reused if they are in a method
                      // at least to my knowledge anyway...
                   
                      
                      // enters first name as string using scanner
                      // the request text is located in docking.txt
                      String fName;
                        Scanner fNameScan = new Scanner(System.in);
                           fName = fNameScan.nextLine();
                         
                      // request text for entering last name
                      System.out.println("");
                      System.out.println("                                                                   Type last name:");
                         // enters last name as a string using a different scanner
                         String lName;
                            Scanner lNameScan = new Scanner(System.in);
                              lName = lNameScan.nextLine();
                     
                      // request text for password    
                      System.out.println("");
                      System.out.println("                                                                   Type password:                    ");
                      System.out.println("");
                      System.out.println("                                                         (This can be any series of letters.)            ");
                         // enters password as a string
                         // originaly, typing this password was supposed to allow the player to bring up the character biography at any time
                         // this idea was scrapped, and it now exists simply to flesh out the docking sequence
                         // also, keyboard smashing is fun
                         String password;
                           Scanner passwordScan = new Scanner(System.in);
                              password = passwordScan.nextLine();
                              
                              
                              
       
       // This part is really hard to find, but a spot I come back to often.
       // For this reason, I am going to put some movie references here so that it is easier to find.
       // Pay no attention to the movie references.
       
       /*
          Did you ever hear the tragedy of Darth Plagueis The Wise? 
          I thought not. 
          It�s not a story the Jedi would tell you. 
          It�s a Sith legend. 
          Darth Plagueis was a Dark Lord of the Sith, 
          so powerful and so wise he could use the Force to influence the midichlorians to create life� 
          He had such a knowledge of the dark side that he could even keep the ones he cared about from dying. 
          The dark side of the Force is a pathway to many abilities some consider to be unnatural. 
          He became so powerful� 
          the only thing he was afraid of was losing his power, 
          which eventually, of course, 
          he did. 
          Unfortunately, 
          he taught his apprentice everything he knew, 
          then his apprentice killed him in his sleep. 
          Ironic. 
          He could save others from death, 
          but not himself.
       */    
       
       /// A little bit more file reading.    
       dockingTwo();
       pressEnter();
   
                         
                        Astronaut astronaut1 = new Astronaut("Name: Elissa Jotare. Proffession: Captain. Home: Earth.");
                        Astronaut astronaut2 = new Astronaut("Name: Kaisar Zelli. Proffession: First Mate. Home: Earth.");
                        Astronaut astronaut3 = new Astronaut("Name: Lucas Sulker. Proffession: Physicist. Home: Demios.");
                        Astronaut astronaut4 = new Astronaut("Name: Marina James. Proffession: Parasitologist. Home: Mars.");
                        Astronaut astronaut5 = new Astronaut("Name: Aranya Samuel. Proffession: Medical Personnel. Home: Titan.");
                        Astronaut astronaut6 = new Astronaut("Name: Brian Mohterre. Proffession: Zoologist. Home: Jupi-Mars Asteroid Belt.");
                        Astronaut astronaut7 = new Astronaut("Name: Glenn-russ frodd. Proffession: Mechanic. Home: Mars.");
                        Astronaut astronaut8 = new Astronaut("Name: Marley Chron. Proffession: Theologist. Home: Moon.");
                        Astronaut astronaut9 = new Astronaut("Name: Peirce Johnson. Proffession: Pilot. Home: Earth.");
                        Astronaut astronaut10 = new Astronaut("Name: Anna Bailey. Proffession: Astronomer. Home: Phobos.");
                        Astronaut astronaut11 = new Astronaut("Name: Lynd Gyro. Proffession: Expeditioner. Home: Earth.");
                          // four reference variables, astronaut1, astronaut2, astronaut3, astronaut4, 
                          // each of which references a new instance of an object of type Astronaut,
                          // created using the non-standard constructor
                  
                          astronaut1.setHeightMeasurement(169.4);
                          astronaut2.setHeightMeasurement(187.6);
                          astronaut3.setHeightMeasurement(168.5);
                          astronaut4.setHeightMeasurement(158.1);
                          astronaut5.setHeightMeasurement(169.6);
                          astronaut6.setHeightMeasurement(158.2);
                          astronaut7.setHeightMeasurement(162.1);
                          astronaut8.setHeightMeasurement(151.2);
                          astronaut9.setHeightMeasurement(155.6);
                          astronaut10.setHeightMeasurement(148.9);
                          astronaut11.setHeightMeasurement(162.1);
                          
                          
                          
                           astronaut1.setAgeMeasurement(42);
                           astronaut2.setAgeMeasurement(37);
                           astronaut3.setAgeMeasurement(51);
                           astronaut4.setAgeMeasurement(36);
                           astronaut5.setAgeMeasurement(34);
                           astronaut6.setAgeMeasurement(29);
                           astronaut7.setAgeMeasurement(45);
                           astronaut8.setAgeMeasurement(41);
                           astronaut9.setAgeMeasurement(33);
                           astronaut10.setAgeMeasurement(30);
                           astronaut11.setAgeMeasurement(35);
                  
                  
                        
                          
                  
                  
                  
                         
                  
                          // set winning percentage (heightMeasurement) for each player (sample percentages)
                          // astronaut1 has winning percentage of 0.61
                          // astronaut2 has winning percentage of 0.19
                          // astronaut3 has winning percentage of 0.81
                          // astronaut4 has winning percentage of 0.42
                  
                          astronaut1.getAstronautName();
                          astronaut1.getHeightMeasurement();
                          astronaut1.getAgeMeasurement();       
                          astronaut2.getAstronautName();
                          astronaut2.getHeightMeasurement();
                          astronaut2.getAgeMeasurement();
                          astronaut3.getAstronautName();
                          astronaut3.getHeightMeasurement();
                          astronaut3.getAgeMeasurement();
                          astronaut4.getAstronautName();
                          astronaut4.getHeightMeasurement();
                          astronaut4.getAgeMeasurement();
                          astronaut5.getAstronautName();
                          astronaut5.getHeightMeasurement();
                          astronaut5.getAgeMeasurement();
                          astronaut6.getAstronautName();
                          astronaut6.getHeightMeasurement();
                          astronaut6.getAgeMeasurement();
                          astronaut7.getAstronautName();
                          astronaut7.getHeightMeasurement();
                          astronaut7.getAgeMeasurement();
                          astronaut8.getAstronautName();
                          astronaut8.getHeightMeasurement();
                          astronaut8.getAgeMeasurement();
                          astronaut9.getAstronautName();
                          astronaut9.getHeightMeasurement();
                          astronaut9.getAgeMeasurement();
                          astronaut10.getAstronautName();
                          astronaut10.getHeightMeasurement();
                          astronaut10.getAgeMeasurement();
                          astronaut11.getAstronautName();
                          astronaut11.getHeightMeasurement();
                          astronaut11.getAgeMeasurement();
                    
                  
                  
                  
                          // invoke the getAstronautName and getWinningPercentage methods
                          // for each Astronaut object, to retrieve that information, and print
                          // it to the screen
                  
                  
                          // create a variable, keyboard, of type Scanner, and set it
                          // equal to a new object of type Scanner, that "listens" to
                          // System.in 
                          Scanner myKeyboard = new Scanner(System.in);
                         
                  
                    // this needs to be outside the for loop, so i can define ageHeight for changing the player age and height later.
                    int ageHeight = 0;
                    
                     // i saw it best to have 2 scanners
                           double playerHeight = 0;       
                              Scanner heightPad = new Scanner(System.in);
                           int playerAge = 0;
                              Scanner agePad = new Scanner(System.in);
                              
                                       
                                              
                  
                             // a while loop repeats biography menu until it is quit
                             for (int a = 0; a < 1;) {
                             
                          // displays names of characters for player to choose from.
                                                   System.out.println("");
                          System.out.println("");
                          System.out.println("                                                           Type name to select personnel:                           ");
                          System.out.println("");
                          System.out.println("                                                                Type 'quit' to quit.                            ");
                          System.out.println("");
                          System.out.println("");
                          System.out.println("Cpt. Jotare");
                          System.out.println("Cdr. Zelii");
                          System.out.println("Prof. Sulker");
                          System.out.println("Dr. James");
                          System.out.println("Ms. Samuel");
                          System.out.println("Dr. Mohterre");
                          System.out.println("Mr. Frodd");
                          System.out.println("Sis. Chron");
                          System.out.println("Lt. Johnson");
                          System.out.println("Prof. Bailey");
                          System.out.println("Spc. Gyro");
                          System.out.println("Dr. " + lName );
                          System.out.println("");
                                
                                
                        String staff;
                           staff = myKeyboard.nextLine();
                        
                          // switch statement displays info for each character, depending on who's name is typed.   
                          switch(staff){
                       case "Cpt. Jotare":
                           System.out.println("");
                              System.out.println("Astronaut " + astronaut1.getAstronautName() + " Height: " + astronaut1.getHeightMeasurement() + "cm. Age: " + astronaut1.getAgeMeasurement() + ".");      
                                 break;
                       case "Cdr. Zelii":
                           System.out.println("");
                              System.out.println("Astronaut " + astronaut2.getAstronautName() + " Height: " + astronaut2.getHeightMeasurement() + "cm. Age: " + astronaut2.getAgeMeasurement() + ".");
                                 break;
                       case "Prof. Sulker": 
                           System.out.println("");
                              System.out.println("Astronaut " + astronaut3.getAstronautName() + " Height: " + astronaut3.getHeightMeasurement() + "cm. Age: " + astronaut3.getAgeMeasurement() + ".");
                                 break;
                       case "Dr. James":
                           System.out.println("");
                              System.out.println("Astronaut " + astronaut4.getAstronautName() + " Height: " + astronaut4.getHeightMeasurement() + "cm. Age: " + astronaut4.getAgeMeasurement() + ".");
                                 break;
                       case "Ms. Samuel":
                           System.out.println(""); 
                              System.out.println("Astronaut " + astronaut5.getAstronautName() + " Height: " + astronaut5.getHeightMeasurement() + "cm. Age: " + astronaut5.getAgeMeasurement() + ".");
                                 break;
                       case "Dr. Mohterre":
                           System.out.println(""); 
                              System.out.println("Astronaut " + astronaut6.getAstronautName() + " Height: " + astronaut6.getHeightMeasurement() + "cm. Age:" + astronaut6.getAgeMeasurement() + ".");
                                 break;
                       case "Mr. Frodd": 
                           System.out.println(""); 
                              System.out.println("Astronaut " + astronaut7.getAstronautName() + " Height: " + astronaut7.getHeightMeasurement() + "cm. Age:" + astronaut7.getAgeMeasurement() + ".");
                                 break;
                       case "Sis. Chron":
                           System.out.println(""); 
                              System.out.println("Astronaut " + astronaut8.getAstronautName() + " Height: " + astronaut8.getHeightMeasurement() + "cm. Age:" + astronaut8.getAgeMeasurement() + ".");
                                 break;
                       case "Lt. Johnson":
                           System.out.println("");  
                              System.out.println("Astronaut " + astronaut9.getAstronautName() + " Height: " + astronaut9.getHeightMeasurement() + "cm. Age:" + astronaut9.getAgeMeasurement() + ".");
                                 break;
                       case "Prof. Bailey": 
                           System.out.println(""); 
                              System.out.println("Astronaut " + astronaut10.getAstronautName() + " Height: " + astronaut10.getHeightMeasurement() + "cm. Age:" + astronaut10.getAgeMeasurement() + ".");
                                 break;
                       case "Spc. Gyro":
                           System.out.println("");  
                              System.out.println("Astronaut " + astronaut11.getAstronautName() + " Height: " + astronaut11.getHeightMeasurement() + "cm. Age:" + astronaut11.getAgeMeasurement() + ".");
                                 break;
                                  
                       case "quit":
                       // exits player from biography menu
                       ++a;
                       break;
                       default :
                       
                                 // this changes the age and height the second time veiwed             
                   
                       if (ageHeight == 0){
                              // height age changing text
                           System.out.println(""); 
                           System.out.println("Astronaut Name: " + fName + " " + lName + ". Proffession: Computer Scientist. Home: Earth. Height: " + ranDoub() + "cm. Age: " + ranInt() + "."); 
                           System.out.println("");
                           System.out.println("");
                           System.out.println("");
                           System.out.println("It looks like the data values for your height and age were corrupted in the data crash.");
                           System.out.println("");
                           System.out.println("Feel free to correct them.");
                           System.out.println("");
                           System.out.println("");
                           System.out.println("");
                          
                         

                            // player input
                           System.out.println("                                                           Type height in cm (abc.d format).                   ");
                           System.out.println("");
                           playerHeight = heightPad.nextDouble();
                           System.out.println("");
                           System.out.println("                                                                Type age in earth years.                  ");
                           System.out.println("");
                           playerAge = agePad.nextInt();
                           System.out.println("");

                           
                           // prevents default age from being opened twice
                           ageHeight = 42069;
                           
                           // else statement displays updated player info.
                       }else{
                           System.out.println("");
                              System.out.println("Astronaut Name: " + fName + " " + lName + ". Proffession: Computer Scientist. Home: Earth. Height: " + playerHeight + "cm. Age: " + playerAge + "."); 
                                 System.out.println("");
                                    System.out.println("");               
                                    }
                                       
                                 break;
                              }       
                          }
       
       
       
       

       // remaining file methods.                   
       pressEnter();
       dockingThree();
       pressEnter();
       darwinIIASCII();
       pressEnter();
         
         // end of file
         System.out.print("Fin");


            }
        }