
import java.util.Scanner; // Import the Scanner class
import java.io.*;         // Import Java I/O classes
// Define a new class
public class pressEnter { 

// method dump

   // reads file StarsPan
   public static void screen()throws IOException{
      String myFileName = "StarsPan.txt";
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
                        
                     }}
    // reads file liftoff
    public static void liftoff()throws IOException{
      String myFileName = "liftoff.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
    
    

}} 
   //reads file Brian
  public static void brian()throws IOException{
      String myFileName = "Brian.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);

}}


public static void brianTwo()throws IOException{
      String myFileName = "Brian 2.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
    
           
    
    
}}           
public static void lind()throws IOException{
      String myFileName = "Lind.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
    
    
}}           
      public static void lindTwo()throws IOException{
      String myFileName = "Lind 2.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
    
    
}}           
     
         public static void docking()throws IOException{
      String myFileName = "Docking.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
    
    

    
}}           
     


  public static void liftoffTwo()throws IOException{
      {
      String myFileName = "liftoff 2.txt";
 
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
                        }
                        
               String choice;
    Scanner scanBoy = new Scanner(System.in);
       choice = scanBoy.nextLine();
        int typoCheck = 0;


           switch(choice){
          
              case "Brian": 
                 brian();
                 pressEnter();
                 brianTwo();
                 break;
              case "Lind": 
                 lind();
                 pressEnter();
                 lindTwo();
                 break;              
              default:
              System.out.println("The pod de-oxygenates. In space, typos are deadly.");
              System.exit(42069);
              }

                          

    
    
}}             
 
     
   public static void title()throws IOException{
      String myFileName = "MinSplash.txt";    
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;    
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
                     
                     }}
    public static void pressEnter() {
    String enter;
    Scanner scanBoy = new Scanner(System.in);
       System.out.println("");
       System.out.println("                                                                    Press enter");
       enter = scanBoy.nextLine();

    }
    
    
    public static void choice() {
        }
    


     public static void main (String[] args) throws IOException
     
     { 
     title();
     pressEnter();
     screen();
     pressEnter();  
     liftoff();
     pressEnter();
     liftoffTwo();
     pressEnter();
     docking();
     pressEnter();

            }
        }

