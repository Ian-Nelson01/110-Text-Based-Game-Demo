
import java.util.Scanner; // Import the Scanner class
import java.io.*;         // Import Java I/O classes
// Define a new class
public class titleCrawl { 

   public static void screen()throws IOException{
      String myFileName = "StarsPan.txt";
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
                        
                     }}
   public static void title()throws IOException{
      String myFileName = "MinSplash.txt";    
      File file = new File(myFileName);
      Scanner inputFile = new Scanner(file);
      int loopNumber = 0;
      while (inputFile.hasNext()){
         ++loopNumber;    
         String fileLine = inputFile.nextLine();
                        System.out.println(fileLine);
                     
                     }}
    public static void pressEnter() {
    String enter;
    Scanner scanBoy = new Scanner(System.in);
       System.out.println("Press enter");
       enter = scanBoy.nextLine();

    }


     public static void main (String[] args) throws IOException
     
     { 
     title();
     pressEnter();
     screen();
     pressEnter();  
            }
        }

