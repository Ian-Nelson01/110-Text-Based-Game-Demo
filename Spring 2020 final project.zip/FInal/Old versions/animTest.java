public class animTest {
   
   // main method
   public static void main (String[] args) {
for (int a = 0; a < 30;) {
++a;
    System.out.println(
    "                                                                                                                                                     ");
System.out.println("                                                ___                     ____                                           ___                          ");
System.out.println("               _dkc         _lkl_           _cddddddoi_             'cdddddddo;_           ,kki       ;d,          _cdddddd,             _'         ");
System.out.println("               ,KNKc       _lKNO_         _lOxi_____ikOi          _oOd;__ __'cOk,          cXXOo_     oXi         ,OO;______             ,o_        ");
System.out.println("               ,OkxOi      lOdOO_         lKo_       _xKi        _dKc         _OO,         cXoiOk'    oXi         iXk_                _'ikXd;_      ");
System.out.println("       __      ,Kd_dO;    cOc'kO_        'OO_         ;Xx_       ,Kx_          cXo         cXc 'xO;   lXi         _ikOdi_             _;oONOl,_     ");
System.out.println("      _c,      ,Kd _xO'  ;Oo _OO_        'Ok_         ,Kx_       ;Xx_          iXo         cXc  _oOl_ lXi           _'cxkxc_             ;x'        ");
System.out.println("    _,dKki_    ,Kd  _kk';Od_ _OO_        _xK;         oKc        _OO,         _dK;         cXc    iOd'oXi               _lKx_            _;_        ");
System.out.println("     _lOx,_    ,Kd   'kOOx_  _OO_         'kOc_     _oOo_         ;OOi_      'dOc          cXc     ,kOOXi         __     ,OO_                       ");
System.out.println("      _i'      ,Ol    ,Ox_   _xx_          _cxkdooodxd,            _lkxdoooodxo'           iOi      _dXK;         ,xdooooxd,                        ");
System.out.println("       _        __     __     __              _',;,__                 _';;;,__             ___        __           _',;,'_                          ");
System.out.println("                                                                                                                                                    ");
                                                                                                                                           

}
}
}